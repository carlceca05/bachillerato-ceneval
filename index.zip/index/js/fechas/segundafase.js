// JavaScript Document


	// Primaria
  var primregistro='15 de abril al 17 de mayo';
  var primportafolio='15 de abril al 24 de mayo';
  var primanio=2013;
  var primresultados='12 de julio';