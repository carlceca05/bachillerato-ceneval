// JavaScript Document

  <!--EXAMEN-->

  var examen='19 de Enero';
  var registro='11 de Noviembre al 13 de Diciembre';
  var resultados='resultados 21 de Marzo';
  var anio=2014;
  var aniob=2013;
  
  <!--LUGAR Y SEDE PESTALOZZI-->
  
  var lugar='Ciudad de M&eacute;xico';  
  var sede='Pestalozzi 711 Col. del Valle C.P. 03100';

  <!--CURSO FIN DE SEMANA1-->

  var diab='S&aacute;bado y Domingo';
  var cursob='26 de Octubre al 18 de Enero';
  var horariob='9:00 am a 2:00 pm';
  var horariob2='8:00 pm a 3:00 pm'
	
  <!--CURSO FIN DE SEMANA2-->
  
  var diac='Dominical';
  var cursoc='8 de Septiembre al 19 de Enero';
  var horarioc='8:00 am a 3:00 pm';
    
  <!--CURSO ENTRE SEMANA1-->
  
  var diaa='Martes, Miercoles y Jueves';
  var cursoa='12 de Noviembre al 16 de Enero';
  var horarioa='9:00 a.m. a 2:00 p.m.';
  var horarioa2='5:00 pm a 10:00pm';

  <!--CURSO ENTRE SEMANA2-->
  
  var diad='Lunes a Viernes';
  var cursod='20 de Mayo al 5 de Septiembre';
  var horariod='7:00 am a 9:00 am';

  <!--LUGAR Y SEDE CUAUHTEMOC-->
  
  var lugarc='Ciudad de M&eacute;xico';  
  var sedec='Av. Cuauhtémoc 876, Col. Narvarte, C.P. 03020';

  <!--CURSO FIN DE SEMANA1-->

  var dia_ca='S&aacute;bado y Domingo';
  var curso_ca='26 de Octubre al 18 de Enero';
  var horario_ca='8:00 am a 2:00 pm';
  var horario_ca2='8:00 pm a 3:00 pm'
	
  <!--CURSO FIN DE SEMANA2-->
  
  var dia_cb='Dominical';
  var curso_cb='8 de Septiembre al 19 de Enero';
  var horario_cb='8:00 am a 3:00 pm';
    
  <!--CURSO ENTRE SEMANA-->
  
  var dia_cc='Martes, Miercoles y Jueves';
  var curso_cc='19 de Noviembre al 16 de Enero';
  var horario_cc='9:00 a.m. a 2:00 p.m.';
  var horario_cc2='5:00 p.m. a 10:00 p.m.'

  <!--CURSO ENTRE SEMANA2-->
  
  var dia_cd='Lunes a Viernes';
  var curso_cd='20 de Mayo al 5 de Septiembre';
  var horario_cd='7:00 am a 9:00 am';
  var horario_cd2=''
  
  <!--LUGAR Y SEDE QUERETARO-->
  
  var lugarqro='Quer&eacute;taro';  
  var sedeqro='Av. universidad y Retablo (arriba del oxxo) <br> Tel&eacute;fono:(442) 212 4712 | (442) 480 4465';
  
  <!--CURSO ENTRE SEMANA1-->
  
  var diaqro='Martes y Jueves';
  var cursoqro='10 de Octubre al 16 de Enero';
  var horarioqro='de 9:00 am a 1:00 pm'
  var horarioqro2='de 6:00 pm a 10:00 pm'
  
  var diaqroc='Lunes, Mi&eacute;rcoles y Viernes';
  var cursoqroc='6 de Noviembre al 17 de Enero';
  var horarioqroc='de 6:00 pm a 10:00 pm'
  var horarioqroc2='de 6:00 pm a 10:00 pm'

  <!--CURSO FIN DE SEMANA1-->
  
  var diaqrob='S&aacute;bado y Domingo';
  var cursoqrob='17 de Noviembre al 18 de Enero';
  var horarioqrob='8:00 am a 3:00 pm'

  <!--LUGAR Y SEDE OAXACA-->
  
  var lugar_oax='Oaxaca';  
  var sede_oax='Czda. de la República 113, Col. Centro, C.P. 68000 <br> Tel&eacute;fono:(951) 515 4206';
  
  <!--CURSO ENTRE SEMANA1-->
  
  var dia_oa='Lunes, Miércoles y Viernes';
  var curso_oa='Inicia 9 de Septiembre';
  var horario_oa1='de 8:00 am a 10:00 am'
  var horario_oa2='de 6:00 pm a 10:00 pm'

  <!--CURSO ENTRE SEMANA2-->
  
  var dia_oa='Martes y Jueves';
  var curso_oa='10 de Septiembre';
  var horario_oa1='de 8:00 am a 10:00 am'
  var horario_oa2='de 6:00 pm a 9:00 pm'

  <!--CURSO FIN DE SEMANA1-->
  
  var dia_ob='Sabatino';
  var curso_ob='7 de Septiembre';
  var horario_ob='8:00 am a 2:00 pm'
  var horario_ob2='8:00 am a 3:00 pm'

  <!--CURSO FIN DE SEMANA2-->
  
  var dia_oc='Dominical';
  var curso_oc='8 de Septiembre';
  var horario_oc='8:00 am a 2:00 pm'
  var horario_oc2='8:00 am a 3:00 pm'
  
    <!--TALLER DE REACTIVOS-->
  
  var diat='Lunea a viernes';
  var cursot='17 al 19 de mayo';
  var horariot='6:00 pm a 10:00pm';
  
    <!--WEB FORM BACHILLERATO CENEVAL-->
	
	
	    <!--
    (function() {
        var IE = /*@cc_on!@*/false;
        if (!IE) { return; }
        if (document.compatMode && document.compatMode == 'BackCompat') {
            if (document.getElementById("af-form-490768817")) {
                document.getElementById("af-form-490768817").className = 'af-form af-quirksMode';
            }
            if (document.getElementById("af-body-490768817")) {
                document.getElementById("af-body-490768817").className = "af-body inline af-quirksMode";
            }
            if (document.getElementById("af-header-490768817")) {
                document.getElementById("af-header-490768817").className = "af-header af-quirksMode";
            }
            if (document.getElementById("af-footer-490768817")) {
                document.getElementById("af-footer-490768817").className = "af-footer af-quirksMode";
            }
        }
    })();
    -->
  
  
  
  
  
  
